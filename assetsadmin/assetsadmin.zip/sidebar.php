<aside class="sidebar sidebar-default">
            <div class="sidebar-profile">
                <img class="img-circle profile-image" src="<?php echo base_url(); ?>assetsadmin/img/favicon.png">

                <div class="profile-body">
                    <h4>Rajawali Nusantara Indonesia 1</h4>
                </div>
            </div>
            <nav>
                <h5 class="sidebar-header">Navigation Menu</h5>
                <ul class="nav nav-pills nav-stacked">
                    <li class="active open">
                        <a href="<?php echo base_url();?>C_Admin" title="Dashboards">
                            <i class="fa fa-lg fa-fw fa-home"></i> Dashboards
                        </a>
                    </li>
                    <li class="nav-dropdown">
                        <a href="#" title="Users">
                            <i class="fa fa-lg fa-fw fa-info-circle"></i> Berita
                        </a>
                        <ul class="nav-sub">
                            <li>
                                <a href="<?php echo base_url();?>C_Admin/lihatBerita" title="Members">
                                    <i class="fa fa-fw fa-info"></i> Lihat Berita
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo base_url();?>C_Admin/tambahBerita" title="Profile">
                                    <i class="fa fa-fw fa-plus-square"></i> Tambah Berita
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-dropdown">
                        <a href="#" title="Users">
                            <i class="fa fa-lg fa-fw fa-folder"></i> Data Produksi
                        </a>
                        <ul class="nav-sub">
                            <li>
                                <a href="<?php echo base_url();?>C_Admin/lihatProduksiKrebet" title="Members">
                                    <i class="fa fa-fw fa-file"></i> Produksi PG Krebet
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo base_url();?>C_Admin/lihatProduksiRejoagung" title="Profile">
                                    <i class="fa fa-fw fa-file"></i> Produksi PG Rejo Agung
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-dropdown">
                        <a href="#" title="Users">
                            <i class="fa fa-lg fa-fw fa-calendar"></i> Kegiatan
                        </a>
                        <ul class="nav-sub">
                            <li>
                                <a href="<?php echo base_url();?>C_Admin/lihatKegiatan" title="Members">
                                    <i class="fa fa-fw fa-calendar"></i> Lihat Kegiatan
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo base_url();?>C_Admin/tambahKegiatan" title="Profile">
                                    <i class="fa fa-fw fa-plus-square"></i> Tambah Kegiatan
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-dropdown">
                        <a href="#" title="Users">
                            <i class="fa fa-lg fa-fw fa-photo"></i> Galeri
                        </a>
                        <ul class="nav-sub">
                            <li>
                                <a href="<?php echo base_url();?>C_Admin/lihatGaleri" title="Members">
                                    <i class="fa fa-fw fa-photo"></i> Lihat Galeri
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo base_url();?>C_Admin/tambahGaleri" title="Profile">
                                    <i class="fa fa-fw fa-plus-square"></i> Tambah Galeri
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                    
                                </ul>
                            </li>
                        </ul>
                    </li>
                    
                </ul>
                
            </nav>
        </aside>