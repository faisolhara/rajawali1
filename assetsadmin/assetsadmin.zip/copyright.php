<footer style="background:#23272d;position:absolute;bottom:0;width:100%;height:25px;
   text-align:center;color:#808080; font-size:13pt; font-family: "Open Sans","Helvetica Neue",Helvetica,Arial,sans-serif;color:#ffffff;">
    © Tim KKN-P & EDP 2015
</footer>